package com.example.rock

interface Callback {
    fun kirimBalikResult (result:Int)
    fun kirimBalikPilihanCom (pilihanCom : String)
}