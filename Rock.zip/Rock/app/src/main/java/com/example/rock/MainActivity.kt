package com.example.rock

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast

private lateinit var  batuCom: ImageView
private lateinit var  kertasCom: ImageView
private lateinit var  guntingCom: ImageView
private  lateinit var batu1 : ImageView
private  lateinit var kertas1 : ImageView
private  lateinit var gunting1 : ImageView
private  lateinit var refresh: ImageView
private lateinit var tulisan : ImageView

class MainActivity : AppCompatActivity(),Callback {
    override fun kirimBalikResult(result: Int) {
        tulisan.setImageResource(result)
    }

    @SuppressLint("ResourceAsColor", "NewApi", "UseCompatLoadingForDrawables")
    override fun kirimBalikPilihanCom(pilihanCom: String) {
        if (pilihanCom == "batu") {
            batuCom.setBackgroundColor(R.color.design_default_color_primary_dark)
        } else if (pilihanCom == "kertas"){
            kertasCom.setBackgroundColor(R.color.design_default_color_primary_dark)
        } else {
            guntingCom.setBackgroundColor(R.color.design_default_color_primary_dark)
    }
}

    @SuppressLint("ResourceAsColor", "NewApi", "UseCompatLoadingForDrawables")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        batu1 = findViewById(R.id.batuPemain1)
        kertas1 = findViewById(R.id.kertasPemain1)
        gunting1 = findViewById(R.id.guntingPemain1)
        refresh = findViewById(R.id.refresh)

        val com = arrayOf("batu", "kertas", "gunting")
        var pencet: Boolean = true
        val controller = Controller(this)

        batu1.setOnClickListener {
            if (pencet) {
                val pilihanCom = com.random()
                batu1.setBackgroundColor(R.color.design_default_color_primary_dark)
                controller.simulasi(pilihan = "batu", pilihanCom = pilihanCom)
                pencet = false
            } else {
                Toast.makeText(this, "Direset dulu broo", Toast.LENGTH_LONG).show()
            }
        }
        kertas1.setOnClickListener {
            if (pencet) {
                val pilihanCom = com.random()
                kertas1.setBackgroundColor(R.color.design_default_color_primary_dark)
                controller.simulasi(pilihan = "kertas", pilihanCom = pilihanCom)
                pencet = false
            } else {
                Toast.makeText(this, "Direset dulu broo", Toast.LENGTH_LONG).show()
            }
        }
        gunting1.setOnClickListener {
            if (pencet) {
                val pilihanCom = com.random()
                gunting1.setBackgroundColor(R.color.design_default_color_primary_dark)
                controller.simulasi(pilihan = "gunting", pilihanCom = pilihanCom)
                pencet = false
            } else {
                Toast.makeText(this, "Direset dulu broo", Toast.LENGTH_LONG).show()
            }
        }

        refresh.setOnClickListener {
            batu1.background = getDrawable(android.R.color.transparent)
            kertas1.background = getDrawable(android.R.color.transparent)
            gunting1.background = getDrawable(android.R.color.transparent)
            batuCom.background = getDrawable(android.R.color.transparent)
            kertasCom.background = getDrawable(android.R.color.transparent)
            guntingCom.background = getDrawable(android.R.color.transparent)
            pencet = true

        }
    }
}


