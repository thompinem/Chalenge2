package com.example.chalenge3_thom.callback

interface Callback2 {
    fun kirimBalikResult2(result2: String)

}