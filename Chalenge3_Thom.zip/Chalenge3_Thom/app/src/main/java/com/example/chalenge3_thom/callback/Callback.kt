package com.example.chalenge3_thom.callback

interface Callback {
    fun kirimBalikResult(result: String)
    fun kirimLagiPilihanCom(pilihanCom:String)
}