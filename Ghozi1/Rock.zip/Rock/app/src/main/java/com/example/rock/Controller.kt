package com.example.rock

import android.util.Log

class Controller(private var callback: Callback) {

    private var result = 0

    fun simulasi(pilihan: String, pilihanCom: String) {
        result = if (pilihan == pilihanCom){
            R.drawable.draw
            Log.d("result","draw")
        }else if(pilihan == "batu" && pilihanCom == "gunting"||
                pilihan == "kertas"&& pilihanCom == "batu"||
                pilihan == "gunting"&& pilihanCom == "kertas"){
            R.drawable.p1menang
            Log.d("result","Player 1 Menang")
        }else{
            R.drawable.p2menang
            Log.d("result","Player 2 Menang")
        }

        callback.kirimBalikPilihanCom(pilihanCom)
        callback.kirimBalikResult(result)
    }
}